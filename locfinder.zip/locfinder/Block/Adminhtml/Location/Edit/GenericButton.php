<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Block\Adminhtml\Location\Edit;

use Magento\Backend\Block\Widget\Context;
use Mage2kish\StoreLocator\Api\LocationRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class GenericButton
 */
class GenericButton
{
    /**
     * @var Context
     */
    private $context;

    /**
     * @var LocationRepositoryInterface
     */
    private $locationRepository;

    /**
     * @param Context $context
     * @param LocationRepositoryInterface $locationRepository
     */
    public function __construct(
        Context $context,
        LocationRepositoryInterface $locationRepository
    ) {
        $this->context = $context;
        $this->locationRepository = $locationRepository;
    }

    /**
     * Return location ID
     *
     * @return int|null
     */
    public function getLocationId()
    {
        try {
            return $this->locationRepository->getById(
                $this->context->getRequest()->getParam('location_id')
            )->getLocationId();
        } catch (NoSuchEntityException $e) {
        }
        return null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }
}
