<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Block\Adminhtml\Location\Edit;

use \Magento\Backend\Block\Template\Context;
use \Mage2kish\StoreLocator\Helper\Config;

/**
 * Base widget class
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 *
 * @SuppressWarnings(PHPMD.NumberOfChildren)
 */
class Map extends \Magento\Backend\Block\Template
{
    /** @var \Mage2kish\StoreLocator\Helper\Config  */
    protected $configStoreLocatorHelper;

    /**
     * @param Context $context
     * @param Config $configStoreLocatorHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Config $configStoreLocatorHelper,
        array $data = []
    ) {
        $this->configStoreLocatorHelper = $configStoreLocatorHelper;
        parent::__construct($context, $data);
    }

    /**
     * Constructor
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('Mage2kish_StoreLocator::location/edit/map.phtml');
    }

    /**
     * Get Google Maps Api Key
     *
     * @return string
     */
    public function getGoogleMapsApiKey()
    {
        return $this->configStoreLocatorHelper->getGoogleMapsApiKey();
    }
}
