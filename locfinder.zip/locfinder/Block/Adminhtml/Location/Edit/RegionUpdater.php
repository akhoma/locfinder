<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Block\Adminhtml\Location\Edit;

/**
 * Base widget class
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 *
 * @SuppressWarnings(PHPMD.NumberOfChildren)
 */
class RegionUpdater extends \Magento\Backend\Block\Template
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('Mage2kish_StoreLocator::location/edit/regionUpdater.phtml');
    }
}
