<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Block;

use \Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Directory\Helper\Data as DirectoryHelper;
use Mage2kish\StoreLocator\Helper\Config as LocationConfigHelper;
use Mage2kish\StoreLocator\Helper\Data as LocationDataHelper;

/**
 * Class Search
 */
class Search extends Template
{
    /**
     * Config helper
     *
     * @var LocationConfigHelper
     */
    private $configHelper;

    /**
     * Location Data helper
     *
     * @var LocationDataHelper
     */
    private $locationDataHelper;

    /**
     * Directory helper
     *
     * @var DirectoryHelper
     */
    private $directoryHelper;

    /**
     * Constructor.
     *
     * @param Context $context
     * @param LocationConfigHelper $configHelper
     * @param DirectoryHelper $directoryHelper
     * @param LocationDataHelper $locationDataHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        LocationConfigHelper $configHelper,
        DirectoryHelper $directoryHelper,
        LocationDataHelper $locationDataHelper,
        array $data = []
    ) {
        $this->configHelper = $configHelper;
        $this->directoryHelper = $directoryHelper;
        $this->locationDataHelper = $locationDataHelper;

        parent::__construct($context, $data);
    }

    /**
     * Get Default Radius
     *
     * @return int
     */
    public function getDefaultRadius()
    {
        return $this->configHelper->getDefaultRadius();
    }

    /**
     * Get Distance Units
     *
     * @return int
     */
    public function getDistanceUnits()
    {
        return $this->configHelper->getDistanceUnits();
    }

    /**
     * Get Distance Units Label
     *
     * @return string
     */
    public function getDistanceUnitsLabel()
    {
        $units = $this->configHelper->getDistanceUnits();
        $unitsLabel = ($units == 'km') ? __('km') : __('miles');

        return $unitsLabel;
    }

    /**
     * Get Google Maps Api Key
     *
     * @return string
     */
    public function getGoogleMapsApiKey()
    {
        return $this->configHelper->getGoogleMapsApiKey();
    }

    /**
     * Get Google Maps Map Styles
     *
     * @return string
     */
    public function getGoogleMapsMapStyles()
    {
        return $this->configHelper->getGoogleMapsMapStyles();
    }

    /**
     * Get countries list
     *
     * @return array
     */
    public function getCountriesList()
    {
        $storeId = $this->_storeManager->getStore()->getId();
        return $this->locationDataHelper->getCountriesListOfAvailableLocations($storeId);
    }

    /**
     * Get Region Json
     *
     * @return string
     */
    public function getRegionJson()
    {
        $storeId = $this->_storeManager->getStore()->getId();
        return $this->locationDataHelper->getRegionJsonOfAvailableLocations($storeId);
    }

    /**
     * Get Search Url
     *
     * @return string
     */
    public function getSearchUrl()
    {
        return $this->getUrl('*/index/search');
    }

    /**
     * Preparing global layout
     *
     * @return void
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        $this->pageConfig->getTitle()->set($this->configHelper->getLocationsPageTitle());
    }
}
