<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\Store;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 *
 */
class Config extends AbstractHelper
{
    /**#@+
     * Config xml path
     */
    const XML_PATH_ENABLED                 = 'storelocator/general/enabled';
    const XML_PATH_DEFAULT_RADIUS          = 'storelocator/general/default_radius';
    const XML_PATH_DISTANCE_UNITS          = 'storelocator/general/distance_units';
    const XML_PATH_LOCATIONS_PAGE_TITLE    = 'storelocator/general/locations_page_title';
    const XML_PATH_GOOGLE_MAPS_API_KEY     = 'storelocator/google/google_maps_api_key';
    const XML_PATH_GOOGLE_MAPS_MAP_STYLES  = 'storelocator/google/google_maps_map_styles';
    /**#@-*/

    /**
     * Get config
     *
     * @param string    $path
     * @param Store|int $store
     * @param string    $scopeType
     * @return mixed
     */
    private function getConfig($path, $store = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        return $this->scopeConfig->getValue($path, $scopeType, $store);
    }

    /**
     * Get default radius
     *
     * @param Store|int $store
     * @return int
     */
    public function getDefaultRadius($store = null)
    {
        return (int) $this->getConfig(self::XML_PATH_DEFAULT_RADIUS, $store);
    }

    /**
     * Get distance units
     *
     * @param Store|int $store
     * @return string
     */
    public function getDistanceUnits($store = null)
    {
        return (string) $this->getConfig(self::XML_PATH_DISTANCE_UNITS, $store);
    }

    /**
     * Get Locations Page Title
     *
     * @param Store|int $store
     * @return string
     */
    public function getLocationsPageTitle($store = null)
    {
        return (string) $this->getConfig(self::XML_PATH_LOCATIONS_PAGE_TITLE, $store);
    }

    /**
     * Get google maps api key
     *
     * @param Store|int $store
     * @return string
     */
    public function getGoogleMapsApiKey($store = null)
    {
        return (string) $this->getConfig(self::XML_PATH_GOOGLE_MAPS_API_KEY, $store);
    }

    /**
     * Get google maps map styles
     *
     * @param Store|int $store
     * @return string
     */
    public function getGoogleMapsMapStyles($store = null)
    {
        return (string) $this->getConfig(self::XML_PATH_GOOGLE_MAPS_MAP_STYLES, $store);
    }

    /**
     * Is Store locator Enabled
     *
     * @param Store|int $store
     * @return bool
     */
    public function isStorelocatorEnabled($store = null)
    {
        return (bool) $this->getConfig(self::XML_PATH_ENABLED, $store);
    }
}
