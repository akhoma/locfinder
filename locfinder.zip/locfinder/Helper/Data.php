<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Helper;

use Mage2kish\StoreLocator\Model\ResourceModel\Location\CollectionFactory as LocationCollectionFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Directory\Model\ResourceModel\Country\CollectionFactory as CountryCollectionFactory;
use Magento\Directory\Model\ResourceModel\Region\CollectionFactory as RegionCollectionFactory;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\Store;

/**
 * Helper Data
 *
 */
class Data extends AbstractHelper
{
    /**
     * Location collection factory
     *
     * @var LocationCollectionFactory
     */
    private $locationCollectionFactory;

    /**
     * Country collection factory
     *
     * @var CountryCollectionFactory
     */
    private $countryCollectionFactory;

    /**
     * Region collection factory
     *
     * @var RegionCollectionFactory
     */
    private $regionCollectionFactory;

    /**
     * Json helper
     *
     * @var JsonHelper
     */
    private $jsonHelper;

    /**
     * Store manager
     *
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * Constructor.
     *
     * @param Context $context
     * @param LocationCollectionFactory $locationCollectionFactory
     * @param CountryCollectionFactory $countryCollectionFactory
     * @param RegionCollectionFactory $regionCollectionFactory
     * @param JsonHelper $jsonHelper
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        LocationCollectionFactory $locationCollectionFactory,
        CountryCollectionFactory $countryCollectionFactory,
        RegionCollectionFactory $regionCollectionFactory,
        JsonHelper $jsonHelper,
        StoreManagerInterface $storeManager
    ) {
        $this->locationCollectionFactory = $locationCollectionFactory;
        $this->countryCollectionFactory = $countryCollectionFactory;
        $this->regionCollectionFactory = $regionCollectionFactory;
        $this->jsonHelper = $jsonHelper;
        $this->storeManager = $storeManager;

        parent::__construct($context);
    }

    /**
     * Get countries list for location search
     *
     * @param Store|int $store
     * @return array
     */
    public function getCountriesListOfAvailableLocations($store = null)
    {
        $locationCollection = $this->locationCollectionFactory->create();
        $storeIds = isset($store) ? [$store] : [];
        $locationCollection->addStoreFilter($storeIds);
        $locationCollection->addFilter('is_active', ['eq' => 1]);
        $locationCollection->getSelect()->reset('columns');
        $locationCollection->getSelect()->columns('country_id');
        $locationCollection->distinct(true);
        $countryIds = [];
        foreach ($locationCollection as $locItem) {
            $countryIds[] = $locItem->getCountryId();
        }

        $countryCollection = $this->countryCollectionFactory->create();
        $countryCollection->addFieldToFilter("country_id", ['in' => $countryIds]);

        return $countryCollection->toOptionArray();
    }

    /**
     * Get Region Json for location search
     *
     * @param Store|int $store
     * @return string
     */
    public function getRegionJsonOfAvailableLocations($store = null)
    {
        $locationCollection = $this->locationCollectionFactory->create();
        $storeIds = isset($store) ? [$store] : [];
        $locationCollection->addStoreFilter($storeIds);
        $locationCollection->addFilter('is_active', ['eq' => 1]);
        $locationCollection->getSelect()->reset('columns');
        $locationCollection->getSelect()->columns('region_id');
        $locationCollection->distinct(true);
        $regionIds = [];
        foreach ($locationCollection as $locItem) {
            $regionIds[] = $locItem->getRegionId();
        }

        $regionCollection = $this->regionCollectionFactory->create();
        $regionCollection->addFieldToFilter("main_table.region_id", ['in' => $regionIds]);
        $regionCollection->load();

        $regionsData = [];
        foreach ($regionCollection as $region) {
            /** @var $region \Magento\Directory\Model\Region */
            if (!$region->getRegionId()) {
                continue;
            }
            $regionsData[$region->getCountryId()][$region->getRegionId()] = [
                'code' => $region->getCode(),
                'name' => (string)__($region->getName()),
            ];
        }

        return $this->jsonHelper->jsonEncode($regionsData);
    }
}
