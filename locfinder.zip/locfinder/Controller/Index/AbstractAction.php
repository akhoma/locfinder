<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Controller\Index;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Store locator index action.
 */
abstract class AbstractAction extends \Magento\Framework\App\Action\Action
{
    /** @var \Mage2kish\StoreLocator\Helper\Config  */
    protected $storeLocatorConfigHelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper
    ) {
        $this->storeLocatorConfigHelper = $storeLocatorConfigHelper;
        parent::__construct($context);
    }

    /**
     * Dispatch request
     *
     * @param RequestInterface $request
     * @return ResponseInterface
     */
    public function dispatch(RequestInterface $request)
    {
        if (!$this->storeLocatorConfigHelper->isStorelocatorEnabled()) {
            $this->_forward('noroute');
        }

        return parent::dispatch($request);
    }
}
