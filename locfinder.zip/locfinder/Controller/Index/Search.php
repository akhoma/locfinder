<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Controller\Index;

use Mage2kish\StoreLocator\Model\ResourceModel\Location\Collection as LocationCollection;
use Mage2kish\StoreLocator\Model\SearchFactory as LocationSearchFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\Store;

/**
 * Store locator index action.
 */
class Search extends AbstractAction
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var LocationSearchFactory
     */
    private $locationSearchFactory;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper
     * @param StoreManagerInterface $storeManager
     * @param LocationSearchFactory $locationSearchFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper,
        StoreManagerInterface $storeManager,
        LocationSearchFactory $locationSearchFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->storeManager = $storeManager;
        $this->locationSearchFactory = $locationSearchFactory;
        parent::__construct($context, $storeLocatorConfigHelper);
    }

    /**
     * Render store locator page
     *
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute()
    {
        $postData = $this->getRequest()->getPostValue();
        $responseData = $this->searchLocations($postData);

        return $this->resultJsonFactory->create()->setData($responseData);
    }

    /**
     * Search locations
     *
     * @param array $searchData
     * @return array
     */
    private function searchLocations($searchData)
    {
        $result = null;
        // add store filter params
        $storeIds = [
            $this->storeManager->getStore()->getId(),
            Store::DEFAULT_STORE_ID
        ];
        $searchData['store_id'] = $storeIds;

        $search = $this->locationSearchFactory->create();

        if (isset($searchData['location_search'])) {
            $locationCollection = $search->searchLocationsByDistance($searchData);
            $result = $this->prepareLocationsDataForResponse($locationCollection);
            if ($searchData['latitude'] || $searchData['longitude']) {
                // add current location info
                $result['currentLocation'] = [
                    'latitude' => $searchData['latitude'],
                    'longitude' => $searchData['longitude'],
                    'radius' => $searchData['radius'],
                ];
            }
        } else {
            $locationCollection = $search->searchLocationsByAddress($searchData);
            $result = $this->prepareLocationsDataForResponse($locationCollection);
        }

        return $result;
    }

    /**
     * Prepare locations data for response
     *
     * @param LocationCollection $locationCollection
     * @return array
     */
    private function prepareLocationsDataForResponse($locationCollection)
    {
        $locationsData = [];
        $result = null;
        $items = $locationCollection->load()->getItems();
        foreach ($items as $item) {
            $locationsData[] = [
                'id' => $item['location_id'],
                'name' => $item['name'],
                'address' => $item->getAddressAsText(),
                'phone' => $item['phone'],
                'latitude' =>  $item['latitude'],
                'longitude' => $item['longitude'],
                'distance' => $item['distance'],
            ];
        }

        $result['locations'] = $locationsData;

        return $result;
    }
}
