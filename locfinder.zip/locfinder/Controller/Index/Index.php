<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Controller\Index;

/**
 * Store locator index action.
 */
class Index extends AbstractAction
{
    /** @var \Magento\Framework\View\Result\PageFactory  */
    private $resultPageFactory;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Mage2kish\StoreLocator\Helper\Config $storeLocatorConfigHelper
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context, $storeLocatorConfigHelper);
    }

    /**
     * Render store locator page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        return $this->resultPageFactory->create();
    }
}
