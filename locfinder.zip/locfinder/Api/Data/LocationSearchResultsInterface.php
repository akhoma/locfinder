<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for location search results.
 * @api
 */
interface LocationSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get locations list.
     *
     * @return \Mage2kish\StoreLocator\Api\Data\LocationInterface[]
     */
    public function getItems();

    /**
     * Set locations list.
     *
     * @param \Mage2kish\StoreLocator\Api\Data\LocationInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
