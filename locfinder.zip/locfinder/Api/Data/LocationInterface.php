<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Mage2kish\StoreLocator\Api\Data;

use Magento\Customer\Api\Data\RegionInterface;

/**
 * StoreLocator Location interface.
 * @api
 */
interface LocationInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const LOCATION_ID   = 'location_id';
    const NAME          = 'name';
    const DESCRIPTION   = 'description';
    const URL           = 'url';
    const PHONE         = 'phone';
    const EMAIL         = 'email';
    const FAX           = 'fax';
    const LATITUDE      = 'latitude';
    const LONGITUDE     = 'longitude';
    const STREET        = 'street';
    const CITY          = 'city';
    const COUNTRY_ID    = 'country_id';
    const REGION        = 'region';
    const REGION_ID     = 'region_id';
    const POSTCODE      = 'postcode';
    const CREATION_TIME = 'creation_time';
    const UPDATE_TIME   = 'update_time';
    const IS_ACTIVE     = 'is_active';
    /**#@-*/

    /**
     * @return int|null
     */
    public function getLocationId();

    /**
     * @param int $locationId
     * @return $this
     */
    public function setLocationId($locationId);

    /**
     * Get location name
     *
     * @return string|null
     */
    public function getName();

    /**
     * Set location name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);

    /**
     * Get location description
     *
     * @return string|null
     */
    public function getDescription();

    /**
     * Set location description
     *
     * @param string $description
     * @return $this
     */
    public function setDescription($description);

    /**
     * Get Url
     *
     * @return string|null
     */
    public function getUrl();

    /**
     * Set Url
     *
     * @param string $url
     * @return $this
     */
    public function setUrl($url);

    /**
     * Get phone
     *
     * @return string|null
     */
    public function getPhone();

    /**
     * Set phone
     *
     * @param string $phone
     * @return $this
     */
    public function setPhone($phone);

    /**
     * Get email
     *
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email);

    /**
     * Get fax
     *
     * @return string|null
     */
    public function getFax();

    /**
     * Set fax
     *
     * @param string $fax
     * @return $this
     */
    public function setFax($fax);
    /**
     * Get location latitude
     *
     * @return float|null
     */
    public function getLatitude();

    /**
     * Set location latitude
     *
     * @param float $latitude
     * @return $this
     */
    public function setLatitude($latitude);

    /**
     * Get location longitude
     *
     * @return float|null
     */
    public function getLongitude();

    /**
     * Set location longitude
     *
     * @param float $longitude
     * @return $this
     */
    public function setLongitude($longitude);

    /**
     * Get street
     *
     * @return string|null
     */
    public function getStreet();

    /**
     * Set street
     *
     * @param string $street
     * @return $this
     */
    public function setStreet($street);

    /**
     * Get city name
     *
     * @return string|null
     */
    public function getCity();

    /**
     * Set city name
     *
     * @param string $city
     * @return $this
     */
    public function setCity($city);

    /**
     * Two-letter country code in ISO_3166-2 format
     *
     * @return string|null
     */
    public function getCountryId();

    /**
     * Set country id
     *
     * @param string $countryId
     * @return $this
     */
    public function setCountryId($countryId);

    /**
     * Get region
     *
     * @return string|null
     */
    public function getRegion();

    /**
     * Set region
     *
     * @param string|null $region
     * @return $this
     */
    public function setRegion($region = null);

    /**
     * Get region ID
     *
     * @return int|null
     */
    public function getRegionId();

    /**
     * Set region ID
     *
     * @param int $regionId
     * @return $this
     */
    public function setRegionId($regionId);

    /**
     * Get postcode
     *
     * @return string|null
     */
    public function getPostcode();

    /**
     * Set postcode
     *
     * @param string $postcode
     * @return $this
     */
    public function setPostcode($postcode);

    /**
     * Get creation time
     *
     * @return string|null
     */
    public function getCreationTime();

    /**
     * Set creation time
     *
     * @param string $creationTime
     * @return $this
     */
    public function setCreationTime($creationTime);

    /**
     * Get update time
     *
     * @return string|null
     */
    public function getUpdateTime();

    /**
     * Set update time
     *
     * @param string $updateTime
     * @return $this
     */
    public function setUpdateTime($updateTime);

    /**
     * Get is active
     *
     * @return bool
     */
    public function getIsActive();

    /**
     * Set is active
     *
     * @param int|bool $isActive
     * @return $this
     */
    public function setIsActive($isActive);
}
