<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * StoreLocator location CRUD interface.
 * @api
 */
interface LocationRepositoryInterface
{
    /**
     * Save location.
     *
     * @param \Mage2kish\StoreLocator\Api\Data\LocationInterface $location
     * @return \Mage2kish\StoreLocator\Api\Data\LocationInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(\Mage2kish\StoreLocator\Api\Data\LocationInterface $location);

    /**
     * Retrieve location.
     *
     * @param int $locationId
     * @return \Mage2kish\StoreLocator\Api\Data\LocationInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($locationId);

    /**
     * Retrieve locations matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Mage2kish\StoreLocator\Api\Data\LocationSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete location.
     *
     * @param \Mage2kish\StoreLocator\Api\Data\LocationInterface $location
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(\Mage2kish\StoreLocator\Api\Data\LocationInterface $location);

    /**
     * Delete location by ID.
     *
     * @param int $locationId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($locationId);
}
