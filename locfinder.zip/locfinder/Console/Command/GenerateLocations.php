<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Console\Command;

use Mage2kish\StoreLocator\Model\LocationFactory;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputArgument;

class GenerateLocations extends Command
{

    private $data = [
        [
            'country_id' => 'US',
            'regions' => [
                [
                    'region_id' => 'NY',
                    'cities' => [
                        [
                            'city_name' => 'New York',
                            'zipcode' => '10038',
                            'streets' => [
                                '110 Wiliam St',
                                '141 Middleville Road',
                                '228 Park Ave S',
                                'Brooklyn Law School. 250',
                                '125 Maiden Lane',
                                '12 Fund for UNICEF'
                            ],
                            'lat' => 40.7127837,
                            'lng' => -74.00594130000002
                        ]
                    ]
                ]
            ],
            'names' => [
                'Coffee shop',
                'Best Furniture',
                'Good Food',
                'Goods',
                'Apples market',
                'Hot Dogs',
                'Red leather',
                'TNMG1',
                'Calenda',
                'Beauty warehouse',
                'Milk and nuts',
                'Weather look',
            ]
        ],
        [
            'country_id' => 'UA',
            'regions' => [
                [
                    'region_id' => '',
                    'cities' => [
                        [
                            'city_name' => 'Kiev',
                            'zipcode' => '03134',
                            'streets' => [
                                '12 Khreschatyk',
                                '141 Obolonska st',
                                '228 Drugetiv',
                                '12 Sobran',
                                'Bulgana 12',
                                'Ratovtsi 4'
                            ],
                            'lat' => 50.4501,
                            'lng' => 30.5234
                        ]
                    ]
                ]
            ],
            'names' => [
                'Kavjarnia',
                'Mnam Mnam',
                'Ovochi ta frukti',
                'Rechi',
                'Jabluka',
                'Vzuttya',
                'Kosmetika',
                'KLF',
                'Elit centr',
                'Kalitka',
                'Moloko ta gorihy',
                'Novynka',
            ]
        ]
    ];

    /**
     * @var LocationFactory
     */
    private $locationFactory;
    /**
     * Inject dependencies
     *
     * @param LocationFactory $locationFactory
     */
    public function __construct(
        LocationFactory $locationFactory
    ) {
        $this->locationFactory = $locationFactory;

        parent::__construct();
    }

    protected function configure()
    {
        $this->setName('mage2kish:storelocator_generate')
            ->setDescription('Generate locations')
            ->setDefinition([
                new InputArgument(
                    'count',
                    InputArgument::OPTIONAL,
                    'Locations count'
                )
            ]);

        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('Generating');

        $count = (int)$input->getArgument('count');
        for($i=0; $i < $count; $i++) {
            $this->generateLocation();
        }
    }

    protected function generateLocation()
    {
        $countryCount = count($this->data);
        $countryNumber = rand(0, $countryCount - 1);
        $countryData = $this->data[$countryNumber];

        $countryId = $countryData['country_id'];

        $regionCount = count($countryData['regions']);
        $regionNumber = rand(0, $regionCount - 1);
        $regionData = $countryData['regions'][$regionNumber];

        $regionId = $regionData['region_id'];

        $citiesCount = count($regionData['cities']);
        $cityNumber = rand(0, $citiesCount - 1);
        $cityData = $regionData['cities'][$cityNumber];

        $city = $cityData['city_name'];
        $zipcode = $cityData['zipcode'];

        $streetsCount = count($cityData['streets']);
        $streetNumber = rand(0, $streetsCount - 1);

        $street = $cityData['streets'][$streetNumber];

        $lat = $cityData['lat'] + rand(0, 100) / 100;
        $lng = $cityData['lng'] + rand(0, 100) / 100;

        //$data = [$countryId, $regionId, $city, $zipcode, $street, $lat, $lng];

        $location = $this->locationFactory->create();

        $namesCount = count($countryData['names']);
        $nameNumber = rand(0, $namesCount - 1);
        $name = $countryData['names'][$nameNumber];

        $location->setName($name);
        $location->setCountryId($countryId);
        $location->setRegionId($regionId);
        $location->setCity($city);
        $location->setPostcode($zipcode);
        $location->setStreet($street);
        $location->setLatitude($lat);
        $location->setLongitude($lng);
        $location->setStoreId([0]);
        $location->setIsActive(1);
        $location->getResource()->save($location);
    }
}
