<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Model;

use Magento\Framework\Model\AbstractModel;
use Magento\Customer\Api\Data\RegionInterface;
use Mage2kish\StoreLocator\Model\ResourceModel\Location as LocationResource;
use Mage2kish\StoreLocator\Api\Data\LocationInterface;

/**
 * Store
 *
 * @method Location setStoreId(array $storeId)
 * @method array getStoreId()
 */
class Location extends AbstractModel implements LocationInterface
{
    /**#@+
     * Location's Statuses
     */
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'mage2kish_storelocator_location';

    /**
     * Initialize resource mode
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(LocationResource::class);
    }

    /**
     * Get location id
     *
     * @return int
     */
    public function getLocationId()
    {
        return $this->_getData(self::LOCATION_ID);
    }

    /**
     * Set location id
     *
     * @param int $locationId
     * @return $this
     */
    public function setLocationId($locationId)
    {
        return $this->setData(self::LOCATION_ID, $locationId);
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->_getData(self::NAME);
    }

    /**
     * Set name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->_getData(self::DESCRIPTION);
    }

    /**
     * Set description
     *
     * @param string $description
     * @return $this
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * Get Url
     *
     * @return string|null
     */
    public function getUrl()
    {
        return $this->_getData(self::URL);
    }

    /**
     * Set Url
     *
     * @param string $url
     * @return $this
     */
    public function setUrl($url)
    {
        return $this->setData(self::URL, $url);
    }

    /**
     * Get phone
     *
     * @return string|null
     */
    public function getPhone()
    {
        return $this->_getData(self::PHONE);
    }
    /**
     * Set phone
     *
     * @param string $phone
     * @return $this
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }

    /**
     * Get email
     *
     * @return string|null
     */
    public function getEmail()
    {
        return $this->_getData(self::EMAIL);
    }

    /**
     * Set email
     *
     * @param string $email
     * @return $this
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * Get fax
     *
     * @return string|null
     */
    public function getFax()
    {
        return $this->_getData(self::FAX);
    }

    /**
     * Set fax
     *
     * @param string $fax
     * @return $this
     */
    public function setFax($fax)
    {
        return $this->setData(self::FAX, $fax);
    }

    /**
     * Get latitude
     *
     * @return string
     */
    public function getLatitude()
    {
        return $this->_getData(self::LATITUDE);
    }

    /**
     * Set latitude
     *
     * @param string $latitude
     * @return $this
     */
    public function setLatitude($latitude)
    {
        return $this->setData(self::LATITUDE, $latitude);
    }

    /**
     * Get longitude
     *
     * @return string
     */
    public function getLongitude()
    {
        return $this->_getData(self::LONGITUDE);
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     * @return $this
     */
    public function setLongitude($longitude)
    {
        return $this->setData(self::LONGITUDE, $longitude);
    }

    /**
     * Get street
     *
     * @return string|null
     */
    public function getStreet()
    {
        return $this->_getData(self::STREET);
    }

    /**
     * Set street
     *
     * @param string $street
     * @return $this
     */
    public function setStreet($street)
    {
        return $this->setData(self::STREET, $street);
    }

    /**
     * Get city name
     *
     * @return string|null
     */
    public function getCity()
    {
        return $this->_getData(self::CITY);
    }

    /**
     * Set city name
     *
     * @param string $city
     * @return $this
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * Two-letter country code in ISO_3166-2 format
     *
     * @return string|null
     */
    public function getCountryId()
    {
        return $this->_getData(self::COUNTRY_ID);
    }

    /**
     * Set country id
     *
     * @param string $countryId
     * @return $this
     */
    public function setCountryId($countryId)
    {
        return $this->setData(self::COUNTRY_ID, $countryId);
    }

    /**
     * Get region
     *
     * @return string|null
     */
    public function getRegion()
    {
        return $this->_getData(self::REGION);
    }

    /**
     * Set region
     *
     * @param string|null $region
     * @return $this
     */
    public function setRegion($region = null)
    {
        return $this->setData(self::REGION, $region);
    }

    /**
     * Get region ID
     *
     * @return int|null
     */
    public function getRegionId()
    {
        return $this->_getData(self::REGION_ID);
    }

    /**
     * Set region ID
     *
     * @param int $regionId
     * @return $this
     */
    public function setRegionId($regionId)
    {
        return $this->setData(self::REGION_ID, $regionId);
    }

    /**
     * Get postcode
     *
     * @return string|null
     */
    public function getPostcode()
    {
        return $this->_getData(self::POSTCODE);
    }
    /**
     * Set postcode
     *
     * @param string $postcode
     * @return $this
     */
    public function setPostcode($postcode)
    {
        return $this->setData(self::POSTCODE, $postcode);
    }

    /**
     * Get creation time
     *
     * @return string
     */
    public function getCreationTime()
    {
        return $this->_getData(self::CREATION_TIME);
    }

    /**
     * Set creation time
     *
     * @param string $creationTime
     * @return $this
     */
    public function setCreationTime($creationTime)
    {
        return $this->setData(self::CREATION_TIME, $creationTime);
    }

    /**
     * Get update time
     *
     * @return string
     */
    public function getUpdateTime()
    {
        return $this->_getData(self::UPDATE_TIME);
    }

    /**
     * Set update time
     *
     * @param string $updateTime
     * @return $this
     */
    public function setUpdateTime($updateTime)
    {
        return $this->setData(self::UPDATE_TIME, $updateTime);
    }

    /**
     * Get is active
     *
     * @return bool
     */
    public function getIsActive()
    {
        return (bool)$this->getData(self::IS_ACTIVE);
    }

    /**
     * Set is active
     *
     * @param bool|int $isActive
     * @return $this
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Receive location store ids
     *
     * @return int[]
     */
    public function getStores()
    {
        return $this->hasData('stores') ? $this->getData('stores') : (array)$this->getData('store_id');
    }

    /**
     * Prepare locations's statuses.
     *
     * @return array
     */
    public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }

    /**
     * Get Address As Text
     *
     * @return string
     */
    public function getAddressAsText()
    {
        // @todo: need to refactor to noy use Object manager and refactor logic maybe
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $countryFactory = $objectManager->get('\Magento\Directory\Model\CountryFactory');
        $countryId = $this->getCountryId() ?: '__';
        $country = $countryFactory->create()->loadByCode($countryId);
        $countryName = $country->getName();

        $regionFactory = $objectManager->get('\Magento\Directory\Model\RegionFactory');
        $region = $regionFactory->create()->loadByCode($this->getRegionId(), $countryId);
        $regionName = $region->getName() ? $region->getName() : $this->getRegion();

        $postcode = $this->getPostcode();
        $city = $this->getCity();
        $street = $this->getStreet();

        $data = [];
        if ($street) {
            $data[] = $street;
        }
        if ($city) {
            $data[] = $city;
        }
        if ($regionName) {
            $data[] = $regionName;
        }
        if ($postcode) {
            $data[] = $postcode;
        }
        if ($countryName) {
            $data[] = $countryName;
        }

        $result = implode(', ', $data);

        return $result;
    }
}
