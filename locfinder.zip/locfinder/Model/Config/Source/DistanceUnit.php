<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Model\Config\Source;

/**
 * Configuration source model for distance unit
 */
class DistanceUnit implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'km', 'label' => __('Kilometers')],
            ['value' => 'ml', 'label' => __('Miles')]
        ];
    }
}
