<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Model;

use Mage2kish\StoreLocator\Api\Data;
use Mage2kish\StoreLocator\Api\LocationRepositoryInterface;
use Mage2kish\StoreLocator\Model\ResourceModel\Location as ResourceLocation;
use Mage2kish\StoreLocator\Model\ResourceModel\Location\CollectionFactory as LocationCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class LocationRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class LocationRepository implements LocationRepositoryInterface
{
    /**
     * @var ResourceLocation
     */
    private $resource;

    /**
     * @var LocationFactory
     */
    private $locationFactory;

    /**
     * @var LocationCollectionFactory
     */
    private $locationCollectionFactory;

    /**
     * @var Data\PLocationSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var \Mage2kish\StoreLocator\Api\Data\LocationInterfaceFactory
     */
    private $dataLocationFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param ResourceLocation $resource
     * @param LocationFactory $locationFactory
     * @param Data\LocationInterfaceFactory $dataLocationFactory
     * @param LocationCollectionFactory $locationCollectionFactory
     * @param Data\LocationSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ResourceLocation $resource,
        LocationFactory $locationFactory,
        Data\LocationInterfaceFactory $dataLocationFactory,
        LocationCollectionFactory $locationCollectionFactory,
        Data\LocationSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->locationFactory = $locationFactory;
        $this->locationCollectionFactory = $locationCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataLocationFactory = $dataLocationFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
    }

    /**
     * Save Location data
     *
     * @param \Mage2kish\StoreLocator\Api\Data\LocationInterface $location
     * @return \Mage2kish\StoreLocator\Api\Data\LocationInterface
     * @throws CouldNotSaveException
     */
    public function save(\Mage2kish\StoreLocator\Api\Data\LocationInterface $location)
    {
        if (empty($location->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $location->setStoreId($storeId);
        }
        try {
            $this->resource->save($location);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the location: %1',
                $exception->getMessage()
            ));
        }
        return $location;
    }

    /**
     * Load Location data by given Location Identity
     *
     * @param string $locationId
     * @return Location
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($locationId)
    {
        $location = $this->locationFactory->create();
        $location->load($locationId);
        if (!$location->getId()) {
            throw new NoSuchEntityException(__('Location with id "%1" does not exist.', $locationId));
        }
        return $location;
    }

    /**
     * Load location data collection by given search criteria
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Mage2kish\StoreLocator\Model\ResourceModel\Location\Collection
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $criteria)
    {
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $collection = $this->locationCollectionFactory->create();
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                if ($filter->getField() === 'store_id') {
                    $collection->addStoreFilter($filter->getValue(), false);
                    continue;
                }
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }
        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $criteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($criteria->getCurrentPage());
        $collection->setPageSize($criteria->getPageSize());
        $locations = [];
        /** @var Location $locationModel */
        foreach ($collection as $locationModel) {
            $locationData = $this->dataLocationFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $locationData,
                $locationModel->getData(),
                'Mage2kish\StoreLocator\Api\Data\LocationInterface'
            );
            $locations[] = $this->dataObjectProcessor->buildOutputDataArray(
                $locationData,
                'Mage2kish\StoreLocator\Api\Data\LocationInterface'
            );
        }
        $searchResults->setItems($locations);
        return $searchResults;
    }

    /**
     * Delete Location
     *
     * @param \Mage2kish\StoreLocator\Api\Data\LocationInterface $location
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(\Mage2kish\StoreLocator\Api\Data\LocationInterface $location)
    {
        try {
            $this->resource->delete($location);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the location: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * Delete Location by given Location Identity
     *
     * @param string $locationId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($locationId)
    {
        return $this->delete($this->getById($locationId));
    }
}
