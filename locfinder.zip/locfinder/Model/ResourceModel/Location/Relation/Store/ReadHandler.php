<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Model\ResourceModel\Location\Relation\Store;

use Mage2kish\StoreLocator\Model\ResourceModel\Location;
use Magento\Framework\EntityManager\MetadataPool;
use Magento\Framework\EntityManager\Operation\ExtensionInterface;

/**
 * Class ReadHandler
 */
class ReadHandler implements ExtensionInterface
{
    /**
     * @var MetadataPool
     */
    private $metadataPool;

    /**
     * @var Location
     */
    private $resourceLocation;

    /**
     * @param MetadataPool $metadataPool
     * @param Location $resourceLocation
     */
    public function __construct(
        MetadataPool $metadataPool,
        Location $resourceLocation
    ) {
        $this->metadataPool = $metadataPool;
        $this->resourceLocation = $resourceLocation;
    }

    /**
     * @param object $entity
     * @param array $arguments
     * @return object
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute($entity, $arguments = [])
    {
        if ($entity->getId()) {
            $stores = $this->resourceLocation->lookupStoreIds((int)$entity->getId());
            $entity->setData('store_id', $stores);
        }
        return $entity;
    }
}
