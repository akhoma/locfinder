<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mage2kish\StoreLocator\Model;

use Mage2kish\StoreLocator\Model\ResourceModel\Location\CollectionFactory as LocationCollectionFactory;

/**
 * Storelocator location search module
 *
 */
class Search
{
    /**
     * Location collection factory
     *
     * @var LocationCollectionFactory
     */
    private $locationCollectionFactory;

    /**
     * Construct
     *
     * @param LocationCollectionFactory $locationCollectionFactory
     */
    public function __construct(
        LocationCollectionFactory $locationCollectionFactory
    ) {
        $this->locationCollectionFactory = $locationCollectionFactory;
    }

    /**
     * Search locations by distance
     *
     * @param array $searchData
     * @return \Mage2kish\StoreLocator\Model\ResourceModel\Location\Collection $locationCollection
     */
    public function searchLocationsByDistance($searchData)
    {
        $geoDistanceFilterParams = [
            'latitude' => $searchData['latitude'],
            'longitude' => $searchData['longitude'],
            'radius' => $searchData['radius'],
        ];

        $locationCollection = $this->locationCollectionFactory->create();
        $this->applyBasicFilters($searchData, $locationCollection);
        $locationCollection->addGeoDistanceFilterAndField($geoDistanceFilterParams);
        $locationCollection->setOrder('distance', 'ASC');

        return $locationCollection;
    }

    /**
     * Search locations by address
     *
     * @param array $searchData
     * @return \Mage2kish\StoreLocator\Model\ResourceModel\Location\Collection $locationCollection
     */
    public function searchLocationsByAddress($searchData)
    {
        $locationCollection = $this->locationCollectionFactory->create();
        $this->applyBasicFilters($searchData, $locationCollection);

        foreach ($searchData as $field => $value) {
            if ($value) {
                switch ($field) {
                    case 'country_id':
                        $locationCollection->addFilter($field, $value);
                        break;
                    case 'region_id':
                        $locationCollection->addFilter($field, $value);
                        break;
                    case 'region':
                        $locationCollection->addFieldToFilter($field, ['like' => "%$value%"]);
                        break;
                    case 'city':
                        $locationCollection->addFieldToFilter($field, ['like' => "%$value%"]);
                        break;
                    case 'postcode':
                        $locationCollection->addFieldToFilter($field, ['like' => "%$value%"]);
                        break;
                    default:
                        break;
                }
            }
        }

        return $locationCollection;
    }

    /**
     * Search locations by address
     *
     * @param array $searchData
     * @param \Mage2kish\StoreLocator\Model\ResourceModel\Location\Collection $collection
     * @return $this
     */
    private function applyBasicFilters($searchData, $collection)
    {
        $collection->addStoreFilter($searchData['store_id']);
        $collection->addFilter('is_active', ['eq' => 1]);

        return $this;
    }
}
