/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint browser:true jquery:true*/
define([
    'underscore',
    "jquery",
    "jquery/ui"
], function (_, $) {
    "use strict";

    /**
     * Main namespace for mage2kish extensions
     * @type {Object}
     */
    $.mage2kish = $.mage2kish || {};

    $.widget('mage2kish.storelocator', {
        options: {
            searchFormSelector: '#location-search-form',
            radiusSliderSelector: '#slider-range',
            mapSelector: '#storelocator-map',
            searchUrl: '',
            defaultRadius: 1000,
            distanceUnits: 'km',
            locationContentItemTemplate: '<div class="location-info"><div class="name"><%= name %></div><div class="address"><%= address %></div><div class="phone"><%= phone %></div></div>',
            mapStyles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}],
            markerOptions: {
                currentLocationMarkerImage: 'http://maps.google.com/mapfiles/marker_grey.png',
                locationMarkerImage: 'http://maps.google.com/mapfiles/marker_white.png',
                currentLocationMarkerStrokeColor: "#21087a",
                currentLocationMarkerStrokeOpacity: 0.8,
                currentLocationMarkerStrokeWeight: 2,
                currentLocationMarkerFillOpacity: 0.2,
                currentLocationMarkerFillColor: "#42b3f4"
            }
        },

        // map elements
        map: null,
        mapMarkers: null,
        currentMarker: null,
        currentMarkerCircle: null,
        markerInfoWindow: null,

        // form elements
        searchForm: null,
        searchElement: null,
        latitudeElement: null,
        longitudeElement: null,
        radiusElement: null,
        radiusLabelValueElement: null,
        searchByRadiusDivElement: null,
        searchByAddressDivElement: null,
        searchDistanceSwitchDivElement: null,
        searchAddressSwitchDivElement: null,
        locationsListElement: null,


        /**
         * Init events
         * @private
         */
        _create: function () {
            this.initSearchFormElements();
            this.initMap();
            this.initRadiusSlider();
            this.initSearch();
            this.initSearchTypeSwitcher();
            this.initLocationsList();
            this.searchAllLocations();
        },

        /**
         * Method initSearchFormElements
         */
        initSearchFormElements: function () {
            this.searchForm = this.element.find(this.options.searchFormSelector);
            this.searchElement = this.searchForm.find("#location_search");
            this.latitudeElement = this.searchForm.find("[name=latitude]");
            this.longitudeElement = this.searchForm.find("[name=longitude]");
            this.radiusElement = this.searchForm.find("[name=radius]");
            this.radiusLabelValueElement = this.element.find("#radius-label-value");
            this.searchByRadiusDivElement =this.element.find("#search-by-distance");
            this.searchByAddressDivElement = this.element.find("#search-by-address");
            this.searchDistanceSwitchDivElement = this.element.find("#search-distance-switch");
            this.searchAddressSwitchDivElement = this.element.find("#search-address-switch");

            this.locationsListElement = this.element.find("#locations-list");
        },

        /**
         * Method initMap
         */
        initMap: function () {
            var mapHtmlElement = this.element.find(this.options.mapSelector).get(0);
            this.map = new google.maps.Map(mapHtmlElement, {
                zoom: 4,
                center: new google.maps.LatLng(0, 0),
                mapTypeControl: false,
                streetViewControl: false,
                fullscreenControl: true,
                zoomControl: true,
                zoomControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_BOTTOM
                },
                styles: this.options.mapStyles
            });

        },

        /**
         * Method initRadiusSlider
         */
        initRadiusSlider: function () {
            var radiusElement = this.radiusElement;
            var radiusLabelValueElement = this.radiusLabelValueElement;
            var debounceSearch = _.debounce(
                function () {
                    this.searchLocations()
                }.bind(this),
                1000
            );
            $(this.options.radiusSliderSelector).slider({
                min: 1,
                max: this.options.defaultRadius,
                step: 1,
                value: this.options.defaultRadius,
                slide: function (event, ui ) {
                    console.log(ui.value);
                    radiusElement.val(ui.value);
                    radiusLabelValueElement.text(ui.value);
                  //  debounceSearch();
                }
            });
        },

        /**
         * Method initSearch
         */
        initSearch: function () {
            var searchHtmlElement = this.searchElement.get(0),
                autoComplete = new google.maps.places.Autocomplete(searchHtmlElement);
            autoComplete.addListener("place_changed", function () {
                var place = autoComplete.getPlace();
                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                    var lat = place.geometry.location.lat(),
                        lng = place.geometry.location.lng();
                    // update form elements values for search
                    this.latitudeElement.val(lat);
                    this.longitudeElement.val(lng);
                } else {
                    this.map.setCenter(place.geometry.location);
                    this.map.setZoom(16);
                }
            }.bind(this));

            // init form search on submit
            this.searchForm.submit(function (event) {
                this.searchLocations();
                event.preventDefault();
            }.bind(this));
        },

        /**
         * Method initMap
         */
        clearMap: function () {
            for (var i in this.mapMarkers) {
                if (this.mapMarkers.hasOwnProperty(i)) {
                    this.mapMarkers[i].setMap(null);
                    delete this.mapMarkers[i];
                }
            }

            if (this.currentMarker) {
                this.currentMarker.setMap(null);
                delete this.currentMarker;
            }

            if (this.currentMarkerCircle) {
                this.currentMarkerCircle.setMap(null);
                delete this.currentMarkerCircle;
            }
        },

        /**
         * Method showLocations
         */
        showLocations: function () {
            var locations = this.locationsData.locations,
                currentLocation = this.locationsData.currentLocation,
                self = this,
                marker;

            this.clearMap();
            this.mapMarkers = [];
            for (var i = 0; i < locations.length; i++) {
                marker = new google.maps.Marker({
                    position: new google.maps.LatLng(
                        parseFloat(locations[i].latitude),
                        parseFloat(locations[i].longitude)
                    ),
                    map: this.map,
                    icon: this.options.markerOptions.locationMarkerImage,
                    title: locations[i].name,
                    address: locations[i].address,
                    phone: locations[i].phone
                });
                this.mapMarkers[locations[i].id] = marker;

                marker.addListener('click', function () {
                    self.zoomAndShowMarker(this);
                });
            }

            if (currentLocation) {
                // current position
                this.currentMarker = new google.maps.Marker({
                    position: new google.maps.LatLng(
                        parseFloat(currentLocation.latitude),
                        parseFloat(currentLocation.longitude)
                    ),
                    map: this.map,
                    icon: this.options.markerOptions.currentLocationMarkerImage
                });
               // this.currentMarker.setVisible(false);

                // current position circle
                this.currentMarkerCircle = new google.maps.Circle({
                    strokeColor: this.options.markerOptions.currentLocationMarkerStrokeColor,
                    strokeOpacity: this.options.markerOptions.currentLocationMarkerStrokeOpacity,
                    strokeWeight: this.options.markerOptions.currentLocationMarkerStrokeWeight,
                    fillColor: this.options.markerOptions.currentLocationMarkerFillColor,
                    fillOpacity: this.options.markerOptions.currentLocationMarkerFillOpacity,
                    center: new google.maps.LatLng(
                        parseFloat(currentLocation.latitude),
                        parseFloat(currentLocation.longitude)
                    ),
                    radius: parseFloat(currentLocation.radius) * 1000,
                    map: this.map
                });
            }

            this.feetMap();
        },

        /**
         * Method feetMap
         */
        feetMap: function () {
            var bounds  = new google.maps.LatLngBounds();

            if (this.currentMarker) {
                bounds.extend(this.currentMarker.getPosition());
            }

            if (this.currentMarkerCircle) {
                bounds.union(this.currentMarkerCircle.getBounds());
            }

            for (var i in this.mapMarkers) {
                if (this.mapMarkers.hasOwnProperty(i)) {
                    bounds.extend(this.mapMarkers[i].getPosition());
                }
            }

            // auto-zoom
            this.map.fitBounds(bounds);
            // auto-center
            this.map.panToBounds(bounds);
        },

        /**
         * Method searchLocations
         */
        searchLocations: function () {
            $.ajax({
                showLoader: true,
                url: this.options.searchUrl,
                data: this.searchForm.find('input:visible, select:visible, input[type=hidden]').serialize(),
                type: "POST",
                dataType: "json"
            }).done(function (data) {
               // alert(JSON.stringify(data));
                this.locationsData = data;
                this.showLocations();
                this.showLocationsList();
            }.bind(this));
        },

        /**
         * Method searchAllLocations
         */
        searchAllLocations: function () {
            $.ajax({
                showLoader: true,
                url: this.options.searchUrl,
                data: {},
                type: "POST",
                dataType: "json"
            }).done(function (data) {
                this.locationsData = data;
                this.showLocations();
                this.showLocationsList();
            }.bind(this));
        },

        /**
         * Method showSearchByDistanceElements
         */
        initSearchTypeSwitcher: function () {
            this.searchDistanceSwitchDivElement.on("click", null, $.proxy(this.showSearchByDistanceElements, this));
            this.searchAddressSwitchDivElement.on("click", null, $.proxy(this.showSearchByAddressElements, this));
        },

        /**
         * Method showSearchByDistanceElements
         */
        showSearchByDistanceElements: function (event) {
            event.preventDefault();
            this.searchDistanceSwitchDivElement.addClass('active');
            this.searchAddressSwitchDivElement.removeClass('active');
            this.showHideSearchElements(this.searchByRadiusDivElement, this.searchByAddressDivElement);
        },

        /**
         * Method showSearchByDistanceElements
         */
        showSearchByAddressElements: function (event) {
            event.preventDefault();
            this.searchDistanceSwitchDivElement.removeClass('active');
            this.searchAddressSwitchDivElement.addClass('active');
            this.showHideSearchElements(this.searchByAddressDivElement, this.searchByRadiusDivElement);
        },

        /**
         * Method showHideSearchElements
         */
        showHideSearchElements: function (elementToShow, elementToHide) {
            elementToShow.removeClass('hide');
            elementToShow.find("input, select").removeAttr("disabled");

            elementToHide.addClass('hide');
            elementToHide.find("input, select").attr("disabled", "disabled");
        },

        /**
         * Method zoomAndShowMarker
         */
        zoomAndShowMarker: function (marker) {
            if (!this.markerInfoWindow) {
                this.markerInfoWindow = new google.maps.InfoWindow({
                    content: ''
                });
            }
            // show info window
            this.markerInfoWindow.setContent(this.generateLocationContent(marker));
            this.markerInfoWindow.open(this.map, marker);

            // set map position to marker
            this.map.setZoom(14);
            this.map.setCenter(marker.getPosition());
            marker.setAnimation(google.maps.Animation.DROP);
        },

        /**
         * Method initLocationsList
         */
        initLocationsList: function () {
            var self = this;
            this.locationsListElement.delegate("li", "click", function () {
                var markerId = $(this).data('locationId');
                if (self.mapMarkers) {
                    self.zoomAndShowMarker(self.mapMarkers[markerId]);
                }
            });
        },

        /**
         * Method showLocationsList
         */
        showLocationsList: function () {
            var locContentListItem,
                itemTmp = _.template('<li class="locations-list-item" data-location-id="<%= id %>"><%= content %></li>');
            this.locationsListElement.find("li").remove();
            if (this.mapMarkers) {
                for (var i in this.mapMarkers) {
                    if (this.mapMarkers.hasOwnProperty(i)) {
                        locContentListItem = itemTmp(
                            {
                                id: i,
                                content: this.generateLocationContent(this.mapMarkers[i])
                            }
                        );
                        this.locationsListElement.append(locContentListItem);
                    }
                }
            }
        },

        /**
         * Method generateLocationContent
         */
        generateLocationContent: function (marker) {
            return _.template(this.options.locationContentItemTemplate)(
                {
                    name: marker.title,
                    address: marker.address,
                    phone: marker.phone
                }
            );
        }
    });

    return $.mage2kish.storelocator;
});
